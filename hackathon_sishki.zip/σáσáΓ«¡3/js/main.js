document.getElementById('recipe-form').addEventListener('submit', async (event) => {
  event.preventDefault();

  const ingredients = document.getElementById('ingredients').value.trim();
  const resultsDiv = document.getElementById('results');
  resultsDiv.innerHTML = '<p>Поиск рецептов...</p>';

  if (!ingredients) {
    resultsDiv.innerHTML = '<p>Пожалуйста, введите ингредиенты.</p>';
    return;
  }

  const spoonacularApiKey = '1189a2f6e1c547849bfa6cd07bf9a750';
  const myMemoryApiKey = '29ed92f8f70eee7a47cf';

  async function translateText(text, from = 'en', to = 'ru') {
     const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${from}|${to}&de=aglazunov076@gmail.com&key=${myMemoryApiKey}`;
    const response = await fetch(url);
    if (!response.ok) throw new Error('Ошибка перевода');
    const data = await response.json();
    return data.responseData.translatedText || text;
  }

  try {
    const translatedIngredients = await translateText(ingredients, 'ru', 'en');

    const encodedIngredients = encodeURIComponent(translatedIngredients);

    const searchUrl = `https://api.spoonacular.com/recipes/findByIngredients?ingredients=${encodedIngredients}&number=3&ranking=2&ignorePantry=true&apiKey=${spoonacularApiKey}`;
    const response = await fetch(searchUrl);
    if (!response.ok) throw new Error('Ошибка Spoonacular API');

    const recipes = await response.json();

    if (!recipes.length) {
      resultsDiv.innerHTML = '<p>Не найдено рецептов с указанными ингредиентами.</p>';
      return;
    }

    let outputHtml = '';

    for (const recipe of recipes) {
      const translatedTitle = await translateText(recipe.title, 'en', 'ru');

      const detailsUrl = `https://api.spoonacular.com/recipes/${recipe.id}/information?includeNutrition=false&apiKey=${spoonacularApiKey}`;
      const detailsResponse = await fetch(detailsUrl);
      if (!detailsResponse.ok) throw new Error('Ошибка получения деталей рецепта');
      const details = await detailsResponse.json();

      const ingredientsListArray = await Promise.all(
        details.extendedIngredients.map(async (ing) => {
          const translatedIng = await translateText(ing.original, 'en', 'ru');
          return `<li>${translatedIng}</li>`;
        })
      );
      const ingredientsList = ingredientsListArray.join('');

      let instructions = '<li>Инструкция недоступна.</li>';
      if (details.analyzedInstructions.length > 0) {
        const stepsArray = await Promise.all(
          details.analyzedInstructions[0].steps.map(async (step) => {
            const translatedStep = await translateText(step.step, 'en', 'ru');
            return `<li>${translatedStep}</li>`;
          })
        );
        instructions = stepsArray.join('');
      }

      outputHtml += `
        <div class="recipe">
          <h2>${translatedTitle}</h2>
          <img src="${details.image}" alt="${translatedTitle}" width="100%" />
          <p>Использовано ингредиентов: ${recipe.usedIngredientCount}</p>
          <p>Пропущено ингредиентов: ${recipe.missedIngredientCount}</p>
          <h3>Необходимые ингредиенты:</h3>
          <ul>${ingredientsList}</ul>
          <h3>Пошаговое приготовление:</h3>
          <ol>${instructions}</ol>
        </div>
        <hr />
      `;
    }

    resultsDiv.innerHTML = outputHtml;

  } catch (error) {
    console.error('Ошибка при получении рецептов:', error);
    resultsDiv.innerHTML = `<p>Произошла ошибка: ${error.message}</p>`;
  }
});